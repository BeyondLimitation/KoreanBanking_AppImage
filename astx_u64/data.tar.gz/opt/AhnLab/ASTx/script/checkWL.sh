gsettings set com.canonical.Unity.Panel systray-whitelist "['all']"
